'''
Question 5 [50 points total - answer all parts]

[35 points] Alice is running an anonymous D-H key exchange with Bob and Eve is eavesdropping their communication in order to decipher the exchanged messages. Eve observes that Alice and Bob use g=7 and p=1404693457, and Alice sent the value A= 785170121 while Bob sent the value B= 413383232. Eve wants to quickly find the shared secret between Alice and Bob. What is the decimal value of this shared secret? Implement a program that recovers the shared secret in less than 30 seconds.
[15 points] Alice and Bob want to convert their shared secret S from the previous part into a residue number representation (RNS) based on the Chinese Remainder Theorem. The CRT base they selected is B=6469693230, which is the product of many small pairwise co-prime moduli. What is the residue of S with respect to each one of these small moduli (i.e., what is the RNS representation of S using B as the base)? Show all your work.
'''
from random import randint
from factordb.factordb import FactorDB

'''
As a result of this attack, the attacker Eve ends up sharing a secret with Alice (gad) and another secret with Bob (gbc), 
'''
#Eve's actions
def Eve(g,p,a,b):
  #drops A:
  c = randint(1,p-1) #picks random exponent c
  print("\nThis is Eves's random exponent c:",c)
  cb = b*c
  scb = pow(g,cb,p) #gcb
  #drops B:
  d = randint(1,p-1) #picks random exponent d
  print("\nThis is Eves's random exponent d:",d)
  ad = a*d
  sad = pow(g,ad,p) #gad
  ab = a*b
  sab = pow(g,ab,p) #gab
  return scb, sad, sab

#Alice's actions
def Alice(a,g,p):
  A = pow(g,a,p)
  return A

#Bob's actions
def Bob(b,g,p):
  B = pow(g,b,p)
  return B

#DLP
def solve_DLP(a, b, m):
	from math import sqrt
	n = int(sqrt (m) + 1)
	#could be more than one solution.
	an = 1
	for i in range(n):
		an = (an * a) % m
	
	vals = dict()
	cur = an
	for p in range(1, n+1):
		if cur not in vals:
			vals[cur] = p
		cur = (cur * an) % m
    	
	result = []
	cur = b
	for q in range(n+1):
		if (cur in vals):
			ans = vals[cur] * n - q
			result.append(ans)
		cur = (cur * a) % m
	return result

def factor(n):
  f = FactorDB(n)
  f.connect()
  result = f.get_factor_list()
  return result

def crt(ss,f):
  for x in range(0, len(f)):
    r = ss % f[x]
    print("\nThis is the residue:",r)


def main():
  print("\nPART A:")
  #given:
  g = 7
  p = 1404693457
  #public values:
  A= 785170121
  B= 413383232
  a = solve_DLP(g,A,p)
  b = solve_DLP(g,B,p)
  print("\nThis is Alice's random exponent a:",a[0])
  print("\nThis is Bob's random exponent b:",b[0])
  ss = Eve(g,p,a[0],b[0])
  print("\nThis is the shared secret:",ss[2]) #g^ab mod p 


  print("\nPART B:")
  #find the residue of S?
  #CRT Base:
  B=6469693230
  factors = factor(B)
  print("\nThese are the factors of base B:", factors) #our m's
  #P(ni) = (x mod ni) × n / ni × (1 / (n / ni) mod ni) mod n 
  #need arb. values?
  CRT = crt(ss[2], factors)
  print("\nThis is the residue:",CRT)
main()