'''
Question 4 [30 points total - answer all parts]

Bob knows that the ElGamal cryptosystem is similar to Diffie-Hellman. To generate the ElGamal keys, Bob selects the cyclic group Z*_p with prime p=20876441 and generator g=5 as the public parameters (in decimal). Bob also selects his secret key X between 1 and p-1. The public parameters are p, g, and the value h=g^X mod p, while the private parameter is X. Bob’s ElGamal encryption uses a random nonce Y between 1 and p-1 and for a given message M between 1 and p-1, and it outputs a pair of values (C1,C2), so that C1=g^Y mod p, and C2=M*(h^Y) mod p. This pair of values is the ciphertext for M with nonce Y (i.e., the ciphertext is a tuple). Also, the value “h^Y mod p” is called the “shared secret” of Bob.

Bob’s ElGamal decryption receives ciphertext (C1,C2) and his secret key X as input and multiplies C2 with the modular multiplicative inverse of the shared secret. Specifically, if “D=C1^X=g^(X*Y) mod p” is the shared secret, and “E=D^(-1) mod p” is the modular multiplicative inverse of the shared secret, the plaintext is “M=E*C2 mod p”.

[5 points] Bob posts on the Internet the encryption of M=20192834 as (C1,C2)=(9916780, 5260862) using nonce Y1. Can you find Bob’s “shared secret” value? Show all you work.
[20 points] Bob posts another ciphertext (C1,C2)= (7350174, 13786334) for a different message M2 using nonce Y2. What is Bob’s message M2? Implement a program that recovers Bob’s message M2.
[5 points] Bob notices that ElGamal encryption is malleable. If the encryption of M3=12345 is (C1,C2)= (8698838, 17288353), what is the encryption of M4=382695 (all numbers are decimal)? Show all your work
'''
from sympy.core.numbers import mod_inverse
import os
import random
import math;  

#ElGama encryption:
def elgama_Enc(m,y,g,p):
  C1 = (g**y) % p
  C2 = M*(h**y) % p
  #h**Y mod p is shared secret.
  return (C1, C2)

#ElGama decryption:
def elgama_Dec(c2,g,p,x,y):
  #D = (c1**x) = g^(Y*X) % p
  xy = x*y
  D = pow(g,xy,p)
  #E = D**-1 % p
  E = pow(D,-1,p)
  #M = E*c2 % p
  M = E*c2 % p
  return M

#geeksforgeeks
def nthRoot(A,N): 
  
    # initially guessing a random number between 
    # 0 and 9 
    xPre = random.randint(1,101) % 10
   
    #  smaller eps, denotes more accuracy 
    eps = 0.001
   
    # initializing difference between two 
    # roots by INT_MAX 
    delX = 2147483647
   
    #  xK denotes current value of x 
    xK=0.0
   
    #  loop untill we reach desired accuracy 
    while (delX > eps): 
  
        # calculating current value from previous 
        # value by newton's method 
        xK = ((N - 1.0) * xPre +
              A/pow(xPre, N-1)) /N 
        delX = abs(xK - xPre) 
        xPre = xK; 
          
    return xK 

#DLP function
def solve_DLP(a, b, m):
	from math import sqrt
	n = int(sqrt (m) + 1)
	#could be more than one solution.
	an = 1
	for i in range(n):
		an = (an * a) % m
	
	vals = dict()
	cur = an
	for p in range(1, n+1):
		if cur not in vals:
			vals[cur] = p
		cur = (cur * an) % m
    	
	result = []
	cur = b
	for q in range(n+1):
		if (cur in vals):
			ans = vals[cur] * n - q
			result.append(ans)
		cur = (cur * a) % m
	return result

def main():
  print("\nPART A:")
  #public chosen parameters:
  p=20876441
  g = 5
  (C1,C2)=(9916780, 5260862) #tuple
  M=20192834
  #equation: 9916780 = 5^Y1 % 20876441
  Y = solve_DLP(5,9916780,20876441)
  Y1 = Y[4]
  print("\nThis is our nonce Y1:", Y1)
  #more than one option/solution?
  value = pow(5,Y1,p)
  print("\nAssertion that:",Y1,"is a solution:",value)
  #equation: 5260862 = M*h^y % 20876441
  #H = (Mod(20192834, 20876441)^-1 * 5260862).nth_root(17)-sagemath.
  h = 5282651
  print("\nThis is our public h:", h)
  #find Bob's shared secret value: “h^Y mod p”
  ss1 = h**Y1 % 20876441
  print("\nThis is Bob's shared secret value:",ss1)
  #finding X:
  x = solve_DLP(5,h,p)
  print("\nThis is Bob's secret value:",x[0])

  print("\nPART B:")
  (C1,C2)= (7350174, 13786334)
  #Need value X, Y2. know h = g**X % p.
  #equation: 7350174 = 5^Y2 % 20876441
  YY = solve_DLP(5,7350174,20876441)
  Y2 = Y[4]
  print("\nThis is our nonce Y2:", Y2)
  value = pow(5,Y2,20876441)
  print("\nAssertion that:",Y2,"is a solution:",value)
  #find M2:
  M2 = elgama_Dec(C2,g,p,x[0],Y2)
  print("\nThis is Bob's M2:",M2)

  print("\nPART C:")
  M3=12345 
  (C1,C2)= (8698838, 17288353)
  M4=382695
  #It is malleable: chosen ciphertext attack.
  #(c1, c2) of some (possibly unknown) message m, one can easily construct a valid encryption (c1, 2c2)of the message 2m
main()