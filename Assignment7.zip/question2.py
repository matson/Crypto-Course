'''
Question 2 [20 points total]

Alice wants Bob to use RSA and digitally sign a message M with SHA-1 hash equal to H=0x9a4636438e6bd94b0103c26d9973680e encoded as a hexadecimal number. Nevertheless, Bob seems reluctant to sign this message, but is happy to sign any other message. Thus, Alice asks Bob to sign the hexadecimal number H’=0x9a4636438e6bd94b0103c26d9973680e00000 and gets the signature S_bob=0x3d99849cce273e20ce5fa8785a29f0bf458b8cfb (hexadecimal number). How can Alice recover Bob’s signature on H? White a program that computes Bob’s signature on H. Bob’s public key is e=0x5 and N=0x68ef91088c021e0fcad6e4b1a8d0c2185182f903 (hexadecimal numbers).
'''

'''
This is a straightfoward example of the Blinding Attack as explained in the textbook.  The goal is to find the third party's signature (Bob's signature on H).  Alice in this case is the attacker. (Eve)

From textbook definitions:

H = M;
Message would knowingly sign: R^eM mod n, = HPrime.
S_bob = (R^eM)^d mod n. (HPrime^d)
Can find M by: 
S_bob = (R^eM)^d = RM^d
M = S_bob/R
*Need to find R, and d.*

'''
from factordb.factordb import FactorDB
from sympy.core.numbers import mod_inverse

#factor function from: https://pypi.org/project/factordb-pycli/
def factor(n):
  f = FactorDB(n)
  f.connect()
  result = f.get_factor_list()
  return result

#inverse of nth root
def inverseExp(n,ex):
  fract = 1.0/ex
  return n**fract

#divide 
def divide(m,n):
  return m/n

def main():
  #textbook version again. Insecure.
  #should also never use SHA-1 as a hash. 
  print("\nIn Decimal...")
  H = int("0x9a4636438e6bd94b0103c26d9973680e",0)
  hPrime = int("0x9a4636438e6bd94b0103c26d9973680e00000",0)
  S_bob = int("0x3d99849cce273e20ce5fa8785a29f0bf458b8cfb",0)
  e = int("0x5",0)
  N = int("0x68ef91088c021e0fcad6e4b1a8d0c2185182f903",0)
  print("\nH:",H,"\nH Prime:",hPrime,"\ne:",e,"\nBob's Sig.",S_bob,"\nmodulus:",N) 
  a = factor(N)
  print("\nThese are the values p and q:","\np:", a[0], "\nq:", a[1])
  not_Mod = mod_inverse(hPrime,N)
  div = divide(not_Mod, H)
  result = inverseExp(div,e)
  sig_M = divide(S_bob,result)
  print("This is the signature for M:", sig_M)
main()