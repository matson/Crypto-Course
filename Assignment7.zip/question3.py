'''
Question 3 [30 points total - answer all parts]

The Paillier Cryptosystem is similar to the RSA cryptosystem, except that operations are modulo N^2 instead of modulo N. In Paillier, key generation starts with two prime numbers p and q of similar bitsize and computes N=p*q and g=N+1. Then for any message M between 0 and N-1, encryption is defined as Enc(M,R)=(g^M)*(R^N) mod N^2, where R is a random nonce. Note, R cannot be a multiple for p or q.

Paillier decryption of a ctxt C is computed using the following steps: Compute D=C^phi(N) mod N^2, compute E=(D-1)/N (note, this is regular division by N), and finally compute M=E*Q modulo N, where Q is the modular multiplicative inverse of phi(N) modulo N (i.e., Q*phi(N) = 1 mod N).

[10 points] Implement Paillier Encryption and Decryption functions based on the description above. You may only use library functions for modular inversion and modular exponentiation.
[15 points] A Paillier ciphertext is C=39978704458215142695346825569 using modulus N^2. What is the corresponding plaintext message M? Implement a program that finds M from the given C. All numbers are in decimal.
[5 points] Observing the definition of Paillier encryption, we observe that it is malleable. If the C1=14603103663208971070515802138 is the encryption of M1=5 and C2=46338061369378272061333682477 is the encryption of M2=7, how can you compute the encryption of M3=12? Show all your work.
'''
import Crypto.Util.number
import random
import string
import os
from math import gcd
#from sympy.ntheory import totient
from sympy.core.numbers import mod_inverse


#bytes to ints.
def bytes_to_Int(bytes):
  result = 0
  for b in bytes:
    result = result * 256 + int(b)
  #print("Converted into ints:",result)
  return result

#ints to bytes.
def int_to_Bytes(value, length):
  result = []
  for i in range(0, length):
      result.append(value >> (i * 8) & 0xff)
  result.reverse()
  bytearr = (bytes(result))
  return bytearr

#checks to see if a number is a multiple of another
def multiple(m, n):
	return True if m % n == 0 else False

#from: https://pycryptodome.readthedocs.io/en/latest/src/util/util.html
def generatePrimes(b):
  p=Crypto.Util.number.getPrime(b, randfunc=Crypto.Random.get_random_bytes)
  q=Crypto.Util.number.getPrime(b, randfunc=Crypto.Random.get_random_bytes)
  return p,q

def compute_N(p,q):
  return (p*q)

def compute_G(n):
  #g=N+1. 
  return (n+1)

def compute_E(d,n):
  #E=(D-1)/N
  return int((d-1)/n)
  #no float arguments

def compute_Q(p,n):
  q = mod_inverse(p,n) 
  return q
  ##Q is the modular multiplicative inverse of phi(N) modulo N (i.e., Q*phi(N) = 1 mod N).

def compute_Phi(p,q):
  return (p-1)*(q-1)

def phi(n):
  result = n
  i = 2
  for i in range(i,i*i <= n):
    if( n % i == 0):
      result -= result / i;
      while (n % i == 0):
        n /= i;
  if (n > 1):
    result -= result / n;
  return result 

def paill_Enc(r,m,g,n):
  #[(g^M)mod(N^2)  *  (R^N)mod(N^2)] mod (N^2)
  N = n**2 #mod squared
  a = pow(g,m,N)
  #print("\n",a)
  b = pow(r,n,N)
  #print("\n",b)
  c = a*b
  cipher = c % N
  return cipher

def paill_Dec(p,n,c):
  N = n**2
  #D=C^phi(N) mod N^2,
  #E=(D-1)/N
  D = pow(c,p,N)
  print("\nThis is the value d:", D)
  E = compute_E(D, n) 
  print("\nThis is the value E:", E) 
  Q = compute_Q(p,n)
  print("\nThis is the value Q:", Q) 
  plain = pow(E,Q,n)
  #M=E*Q modulo N
  return plain

def main():

  #part a:
  bits = 60
  #key pairs: p and q must be random prime numbers
  #plaintext must be 0-n-1 size.
  p,q = generatePrimes(bits)
  print("\nRandom n-bit Prime (p):",p)
  print("\nRandom n-bit Prime (q): ",q)
  mod_N = compute_N(p,q)
  g = compute_G(mod_N)
  print("\nModulus N:",mod_N)
  print("\nValue g:",g)
  M = random.getrandbits(60)
  print("\nThis is my message:",M)
  R = os.urandom(16)
  Rv = bytes_to_Int(R)
  print("\nThis is my nonce R:",Rv)
  test1 = multiple(Rv,p)
  print("\nIs R a multiple of q? :",test1)
  test2 = multiple(Rv,p)
  print("\nIs R a multiple of p? :",test2)

  test =  int(phi(mod_N))
  print("This is the test:",test)
  C = paill_Enc(Rv,M,g,mod_N)
  print("\nThis is the cipher:",C)
  phi_n = compute_Phi(p,q)
  print("\nThis is phi(n):", phi_n)
  P = paill_Dec(test,mod_N,C)
  print("\nBack to plain Message:",P)

  #part b:
  print("\nPART B:")
  Cb=39978704458215142695346825569
  N = mod_N**2 #mod
  phi_b = 26015614278903786240
  Mb = paill_Dec(phi_b,N,Cb)
  print("\nThis is the corresponding plaintext message M:",Mb)
  #need phi, C and mod parameters for decryption.

  #part c:
  print("\nPART C:")
  C1=14603103663208971070515802138 
  M1=5
  C2=46338061369378272061333682477
  M2=7
  #y1 × y2 mod n = x1e × x2e mod n = (x1 × x2)e mod n
  #create a new valid ciphertext from two RSA ciphertexts.
  #this explains the reason it is malleable.
  C3 = (C1*C2) % N
  print("\nThis is the third ciphertext C3:", C3)
main()