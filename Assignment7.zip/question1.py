'''
Question 1 [30 points total - answer all parts]

a.)[10 points] Bob is learning cryptography and has implemented the RSA cryptosystem using the description in Section V of the original paper (https://people.csail.mit.edu/rivest/Rsapaper.pdf (Links to an external site.)). Bob selects e=17 and N=38210080753993935337519 and keeps his d, p and q private. Then he encrypts a secret number M and sends ctxt C=29202530725918700842079 to Alice. Can you find M? Write a program that can recover M. Note, all given numbers are in decimal.

b.)[10 points] Bob thinks the public exponent e=17 is unnecessarily large and wants to find the smallest prime that works with his RSA implementation. He generates new primes and selects e=3 and N=237586812181653994808797835837127641 as his public RSA key. Then he encrypts a 38-bit number M and sends the ctxt C=14621362594515611576696983236378624 to Alice. Can you find M? Write a program that can recover M. Note, all given numbers are in decimal.

c.)[10 points] Bob thinks generating two prime numbers for RSA takes a very long time. He decides to generate the RSA public key using one prime and selects e=65537 and N=782411451307002751974547518481. Then he encrypts a number M and sends the ctxt C=750555647839236294597477460513 to Alice. Can you find M? Write a program that can recover M. Note, all given numbers are in decimal.
'''
'''
"Anything about 600-bit can be factored by GNFS." -Wiki.
  -know e, N, and C.
  -d is the trapdoor to decryption
  -low security of N: factoring is possible.
'''
from factordb.factordb import FactorDB
from sympy.core.numbers import mod_inverse

'''
**must insall factordb and sympy with pip command**
'''

#factor function from: https://pypi.org/project/factordb-pycli/
def factor(n):
  f = FactorDB(n)
  f.connect()
  result = f.get_factor_list()
  return result

#finding phi(n)
def find_Phi(p,q):
  return (p-1)*(q-1)

def decrypt(c,d,n):
  #D(C) ≡ C^d (mod n).
  return ((c**d) % n)

def main():
  #Bob is using the textbook version of RSA, therefore it is easily breakable.
  #part a: given
  print("\nPART A:")
  e1 = 17
  N1=38210080753993935337519 #23 numbers, less than 80 bits of security
  C1=29202530725918700842079
  #calculated:
  factors1 = factor(N1)
  print("\nThese are the factors:",factors1)
  p1 = factors1[0]
  q1 = factors1[1]
  print("\nThis is part A's p and q:", p1, q1)
  phi_A = find_Phi(p1,q1)
  print("\nThis is part A's phi:", phi_A)
  d1 = mod_inverse(phi_A, e1)
  print("\nThis is the part A's trapdoor:", d1)
  M1 = decrypt(C1,d1,N1)
  print("\nThis is part A's final message:", M1)

  #part b:
  print("\nPART B:")
  e2 = 3
  N2=237586812181653994808797835837127641 #less than 126 bits of security
  #38-bit number M
  C2=14621362594515611576696983236378624
  factors2 = factor(N2)
  print("\nThese are the factors:", factors2)
  p2 = factors2[0]
  q2 = factors2[1]
  print("\nThis is part B's p and q:", p2, q2)
  phi_B = find_Phi(p2,q2)
  print("\nThis is part B's phi:", phi_B)
  d2 = mod_inverse(phi_B, e2)
  print("\nThis is the part B's trapdoor:", d2)
  M2 = decrypt(C2,d2,N2)
  print("\nThis is part B's final message:", M2)

  #part c:
  print("\nPART C:")
  #uses only p or q. not both.
  e=65537
  N3=782411451307002751974547518481.
  C3=750555647839236294597477460513 
  factors3 = factor(N3)
  print("\nThese are the factors:", factors3)
  p3 = factors3[0]
  q3 = factors3[1]
  #find phi?
  main()